//
//  FirstViewController.h
//  XMLTest
//
//  Created by Javi on 17/01/13.
//  Copyright (c) 2013 Javi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController {
    NSMutableArray *tableContent;


}
@property (weak, nonatomic) IBOutlet UITableView *tableView;



@end
