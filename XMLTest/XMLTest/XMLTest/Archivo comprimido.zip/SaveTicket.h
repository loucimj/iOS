//
//  SaveTicket.h
//  XMLTest
//
//  Created by Javi on 24/01/13.
//  Copyright (c) 2013 Javi. All rights reserved.
//

#import "MTXMLLists.h"

@interface SaveTicket : MTXMLLists

@property IBOutlet NSMutableDictionary *ticketInfo;
@property IBOutlet NSMutableArray *resultSet;
@end
