//
//  GetCreditCardList.h
//  XMLTest
//
//  Created by Javier Loucim on 23/01/13.
//  Copyright (c) 2013 Javi. All rights reserved.
//

#import "MTXMLLists.h"

@interface GetCreditCardList : MTXMLLists

@property IBOutlet NSString *creditCardHolder;

@end
